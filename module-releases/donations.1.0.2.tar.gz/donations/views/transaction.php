<?php
if ( ! defined( 'METIS_ROOT' ) ) exit;

$base_url = metis_donations_base_url();
$tid      = metis_donations_request_identifier( 'tid', 'transaction' );

if ( $tid === '' ) : ?>
    <h1 class="metis-page-title">Transaction Not Found</h1>
    <p class="metis-subtitle">No Transaction ID was provided.</p>
    <a href="<?php echo metis_escape_url( $base_url . '/transactions/' ); ?>" class="metis-btn metis-btn-xs">← Back</a>
    <?php return;
endif;
$snapshot = \Metis\Modules\Donations\ReadService::transactionDetailSnapshot( $tid );
$transaction = $snapshot['transaction'] ?? null;

if ( ! $transaction ) : ?>
    <h1 class="metis-page-title">Transaction Not Found</h1>
    <p class="metis-subtitle">We couldn't match that transaction ID.</p>
    <a href="<?php echo metis_escape_url( $base_url . '/transactions/' ); ?>" class="metis-btn metis-btn-xs">← Back</a>
    <?php return;
endif;

// Core values
$donor_name   = trim( $transaction->first_name . ' ' . $transaction->last_name );
$campaign     = $transaction->campaign_name ?: $transaction->campaign_code ?: '—';
$amount_raw   = (float) $transaction->amount;
$fee_raw      = $transaction->fee    !== null ? (float) $transaction->fee    : 0.0;
$payout_raw   = $transaction->payout !== null ? (float) $transaction->payout : 0.0;
$gross_raw    = $amount_raw + $fee_raw;

$display_date = $transaction->tran_date ? date( 'm/d/Y', strtotime( $transaction->tran_date ) ) : '—';
metis_set_page_title( $transaction->tid );
$donor_url    = metis_donations_detail_url( 'donor', (string) ( $transaction->did ?: $transaction->donor_did ) );
$stripe_refund_available = ! empty( $transaction->stripe_charge_id ) || ! empty( $transaction->stripe_pay_int );

$batch_code = ! empty( $transaction->deposit_batch_id ) ? $transaction->deposit_batch_id : '';
$batch_url  = $batch_code ? metis_donations_detail_url( 'batch', (string) $batch_code ) : '';
$refunds = $snapshot['refunds'] ?? [];
$campaign_options = $snapshot['campaign_options'] ?? [];
$action_nonces = [
    'metis_add_transaction_note' => metis_runtime_create_nonce( metis_ajax_nonce_action( 'metis_add_transaction_note' ) ),
    'metis_record_transaction_refund' => metis_runtime_create_nonce( metis_ajax_nonce_action( 'metis_record_transaction_refund' ) ),
    'metis_update_transaction_campaign' => metis_runtime_create_nonce( metis_ajax_nonce_action( 'metis_update_transaction_campaign' ) ),
];

$total_refunded_raw = array_sum( array_map( fn($r) => (float) $r->amount, $refunds ) );
$notes = $snapshot['notes'] ?? [];
?>

<h1 class="metis-page-title">Transaction <?php echo metis_escape_html( $transaction->tid ); ?></h1>
<p class="metis-subtitle">Detailed record for this donation.</p>
<p><a href="<?php echo metis_escape_url( $donor_url ); ?>" class="metis-btn metis-btn-xs">← Back to Donor</a></p>

<!-- SUMMARY CARD -->
<div class="metis-summary-grid metis-transaction-summary">
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Donor</div>
        <div class="large-number"><?php echo metis_escape_html( $donor_name ?: '—' ); ?></div>
        <?php if ( $transaction->email ) : ?>
            <div class="metis-muted metis-transaction-meta-text"><?php echo metis_escape_html( $transaction->email ); ?></div>
        <?php endif; ?>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Campaign</div>
        <div class="large-number" id="metis-transaction-campaign-label"><?php echo metis_escape_html( $campaign ); ?></div>
        <form class="metis-inline-form metis-transaction-campaign-form" id="metis-transaction-campaign-form">
            <input type="hidden" name="tid" value="<?php echo metis_escape_attr( $transaction->tid ); ?>">
            <label class="metis-screen-reader-text" for="metis-transaction-campaign-select">Campaign</label>
            <select class="metis-select" id="metis-transaction-campaign-select" name="campaign_code">
                <option value="">Select campaign</option>
                <?php foreach ( $campaign_options as $option ) :
                    $option_id = (string) ( $option->cid ?? '' );
                    if ( $option_id === '' ) {
                        continue;
                    }
                    $option_label = (string) ( $option->cname ?? $option_id );
                    if ( ! empty( $option->active ) ) {
                        $option_label .= ' (Active)';
                    }
                ?>
                    <option value="<?php echo metis_escape_attr( $option_id ); ?>" <?php metis_attr_selected( (string) ( $transaction->campaign_code ?? '' ), $option_id ); ?>>
                        <?php echo metis_escape_html( $option_label ); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="metis-btn metis-btn-xs">Save Campaign</button>
        </form>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Amount</div>
        <div class="large-number">$<?php echo number_format( $amount_raw, 2 ); ?></div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Date</div>
        <div class="large-number"><?php echo metis_escape_html( $display_date ); ?></div>
    </div>
</div>

<!-- DETAILS -->
<h2 class="metis-page-title metis-transaction-section-title">Details</h2>
<div class="metis-summary-grid metis-transaction-details">
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Status</div>
        <div><?php echo metis_status_badge( $transaction->status ); ?></div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Payment Method</div>
        <div><?php echo metis_paymethod_badge_with_details( $transaction->payment_method, $transaction ); ?></div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Deposit</div>
        <div>
            <?php echo metis_deposit_badge( $transaction->deposit_date ); ?>
            <?php if ( $batch_code ) : ?>
                <div class="metis-transaction-batch-row">
                    <span class="metis-muted">Batch:</span>
                    <a href="<?php echo metis_escape_url( $batch_url ); ?>" class="metis-batch-link">
                        <?php echo metis_escape_html( $batch_code ); ?>
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Platform</div>
        <div class="large-number"><?php echo metis_escape_html( metis_platform_label( $transaction->platform ) ); ?></div>
    </div>
</div>

<!-- FINANCIAL SUMMARY -->
<h2 class="metis-page-title metis-transaction-section-title">Financial Summary</h2>
<div class="metis-summary-grid metis-transaction-financial">
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Gross Amount</div>
        <div class="large-number">$<?php echo number_format( $gross_raw, 2 ); ?></div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Fees</div>
        <div class="large-number"><?php echo $fee_raw > 0 ? '$' . number_format( $fee_raw, 2 ) : '—'; ?></div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Net Payout</div>
        <div class="large-number"><?php echo $payout_raw > 0 ? '$' . number_format( $payout_raw, 2 ) : '—'; ?></div>
    </div>
    <div class="metis-premium-cell">
        <div class="metis-muted small-label">Total Refunded</div>
        <div class="large-number" id="metis-total-refunded">$<?php echo number_format( $total_refunded_raw, 2 ); ?></div>
        <div class="metis-muted metis-transaction-meta-text" id="metis-net-after-refunds"<?php echo $total_refunded_raw > 0 ? '' : ' hidden'; ?>>
            Net after refunds: $<?php echo number_format( $amount_raw - $total_refunded_raw, 2 ); ?>
        </div>
    </div>
</div>

<!-- REFUND HISTORY -->
<h2 class="metis-page-title metis-transaction-section-title">Refund History</h2>
<div class="metis-detail-panel metis-transaction-refunds">
    <form class="metis-inline-form metis-transaction-refund-form" id="metis-transaction-refund-form">
        <input type="hidden" name="tid" value="<?php echo metis_escape_attr( $transaction->tid ); ?>">
        <input class="metis-input" type="number" min="0.01" step="0.01" name="amount" placeholder="Amount">
        <select class="metis-input" name="source">
            <?php if ( $stripe_refund_available ) : ?>
                <option value="stripe">Stripe refund</option>
            <?php endif; ?>
            <option value="manual"<?php echo $stripe_refund_available ? '' : ' selected'; ?>>Manual record</option>
        </select>
        <input class="metis-input" type="text" name="reason" placeholder="Reason">
        <textarea class="metis-input" name="notes" rows="2" placeholder="Internal refund notes"></textarea>
        <button type="submit" class="metis-btn metis-btn-xs">Submit Refund</button>
    </form>
    <?php if ( ! empty( $refunds ) ) : ?>
        <div class="metis-refund-header-row" id="metis-refund-header-row">
            <div class="metis-ref-col">Amount</div>
            <div class="metis-ref-col">Date</div>
            <div class="metis-ref-col">By</div>
            <div class="metis-ref-col">Source</div>
            <div class="metis-ref-col">Reason</div>
        </div>
        <?php foreach ( $refunds as $r ) : ?>
            <div class="metis-refund-row">
                <div class="metis-ref-col">$<?php echo number_format( (float) $r->amount, 2 ); ?></div>
                <div class="metis-ref-col"><?php echo $r->refund_display_date ? metis_escape_html( date( 'm/d/Y H:i', strtotime( $r->refund_display_date ) ) ) : '—'; ?></div>
                <div class="metis-ref-col"><?php echo metis_escape_html( $r->display_name ?: 'System' ); ?></div>
                <div class="metis-ref-col"><?php echo metis_escape_html( ucfirst( $r->source ?: 'manual' ) ); ?></div>
                <div class="metis-ref-col"><?php echo metis_escape_html( $r->reason ?: '—' ); ?></div>
            </div>
        <?php endforeach; ?>
    <?php else : ?>
        <p class="metis-muted" id="metis-transaction-refunds-empty">No refunds recorded for this transaction.</p>
    <?php endif; ?>
</div>

<!-- NOTES -->
<h2 class="metis-page-title metis-transaction-section-title">Internal Notes</h2>
<div class="metis-detail-panel metis-transaction-notes">
    <form class="metis-inline-form metis-transaction-note-form" id="metis-transaction-note-form">
        <input type="hidden" name="tid" value="<?php echo metis_escape_attr( $transaction->tid ); ?>">
        <textarea class="metis-input" name="note" rows="3" placeholder="Add internal note"></textarea>
        <button type="submit" class="metis-btn metis-btn-xs">Add Note</button>
    </form>
    <?php if ( ! empty( $notes ) ) : ?>
        <ul class="metis-notes-list" id="metis-transaction-notes-list">
            <?php foreach ( $notes as $n ) : ?>
                <li class="metis-note-item">
                    <div class="metis-note-meta">
                        <span class="metis-note-author"><?php echo metis_escape_html( $n->display_name ?: 'System' ); ?></span>
                        <span class="metis-note-date metis-muted"> · <?php echo $n->created_at ? metis_escape_html( date( 'm/d/Y H:i', strtotime( $n->created_at ) ) ) : '—'; ?></span>
                    </div>
                    <div class="metis-note-body"><?php echo nl2br( metis_escape_html( $n->note ) ); ?></div>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else : ?>
        <p class="metis-muted" id="metis-transaction-notes-empty">No notes yet for this transaction.</p>
    <?php endif; ?>
</div>

<script>
(function() {
    'use strict';

    var ACTION_NONCES = <?php echo json_encode( $action_nonces ); ?>;

    function esc(value) {
        return String(value || '').replace(/[&<>"']/g, function(ch) {
            return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch];
        });
    }

    function actionBody(action, fields) {
        var body = new URLSearchParams(Object.assign({ action: action }, fields || {}));
        var fallback = window.metisAjax && metisAjax.nonce ? metisAjax.nonce : '';
        var localNonce = ACTION_NONCES[action] || '';
        var nonce = window.Metis && Metis.ajax && typeof Metis.ajax.nonceFor === 'function'
            ? Metis.ajax.nonceFor(action, localNonce || fallback)
            : (localNonce || fallback);
        body.set('metis_action_nonce', nonce);
        return body;
    }

    function post(action, fields) {
        return fetch(metisAjax.ajax_url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: actionBody(action, fields)
        }).then(function(response) { return response.json(); });
    }

    function toast(message, type) {
        if (window.Metis && Metis.ui && Metis.ui.toast && typeof Metis.ui.toast[type || 'info'] === 'function') {
            Metis.ui.toast[type || 'info'](String(message || ''));
        }
    }

    document.getElementById('metis-transaction-note-form')?.addEventListener('submit', function(event) {
        event.preventDefault();
        var form = event.currentTarget;
        var note = (form.note.value || '').trim();
        if (!note) return;

        post('metis_add_transaction_note', { tid: form.tid.value, note: note }).then(function(result) {
            if (!result || !result.success) {
                toast((result && result.data && result.data.message) || 'Failed to save note.', 'error');
                return;
            }
            document.getElementById('metis-transaction-notes-empty')?.remove();
            var list = document.getElementById('metis-transaction-notes-list');
            if (!list) {
                list = document.createElement('ul');
                list.className = 'metis-notes-list';
                list.id = 'metis-transaction-notes-list';
                form.insertAdjacentElement('afterend', list);
            }
            var row = result.data && result.data.note ? result.data.note : { note: note, display_name: 'You', created_at: 'Just now' };
            var li = document.createElement('li');
            li.className = 'metis-note-item';
            li.innerHTML = '<div class="metis-note-meta"><span class="metis-note-author">' + esc(row.display_name || 'You') + '</span><span class="metis-note-date metis-muted"> · Just now</span></div><div class="metis-note-body">' + esc(row.note).replace(/\n/g, '<br>') + '</div>';
            list.prepend(li);
            form.note.value = '';
            toast('Note saved.', 'success');
        }).catch(function() {
            toast('Request failed.', 'error');
        });
    });

    document.getElementById('metis-transaction-refund-form')?.addEventListener('submit', function(event) {
        event.preventDefault();
        var form = event.currentTarget;
        var amount = parseFloat(form.amount.value || '0');
        if (!(amount > 0)) return;

        post('metis_record_transaction_refund', {
            tid: form.tid.value,
            amount: form.amount.value,
            reason: form.reason.value || '',
            notes: form.notes.value || '',
            source: form.source.value || 'manual'
        }).then(function(result) {
            if (!result || !result.success) {
                toast((result && result.data && result.data.message) || 'Failed to record refund.', 'error');
                return;
            }
            var data = result.data || {};
            var refund = data.refund || {};
            document.getElementById('metis-transaction-refunds-empty')?.remove();
            var panel = document.querySelector('.metis-transaction-refunds');
            var header = document.getElementById('metis-refund-header-row');
            if (!header && panel) {
                header = document.createElement('div');
                header.className = 'metis-refund-header-row';
                header.id = 'metis-refund-header-row';
                header.innerHTML = '<div class="metis-ref-col">Amount</div><div class="metis-ref-col">Date</div><div class="metis-ref-col">By</div><div class="metis-ref-col">Source</div><div class="metis-ref-col">Reason</div>';
                form.insertAdjacentElement('afterend', header);
            }
            if (header) {
                var row = document.createElement('div');
                row.className = 'metis-refund-row';
                row.innerHTML = '<div class="metis-ref-col">$' + Number(refund.amount || amount).toFixed(2) + '</div><div class="metis-ref-col">Just now</div><div class="metis-ref-col">' + esc(refund.display_name || 'You') + '</div><div class="metis-ref-col">' + esc(refund.source || 'manual') + '</div><div class="metis-ref-col">' + esc(refund.reason || '-') + '</div>';
                header.insertAdjacentElement('afterend', row);
            }
            if (typeof data.total_refunded !== 'undefined') {
                document.getElementById('metis-total-refunded').textContent = '$' + Number(data.total_refunded || 0).toFixed(2);
            }
            if (typeof data.net_after_refunds !== 'undefined') {
                var net = document.getElementById('metis-net-after-refunds');
                net.hidden = false;
                net.textContent = 'Net after refunds: $' + Number(data.net_after_refunds || 0).toFixed(2);
            }
            form.reset();
            toast('Refund recorded.', 'success');
        }).catch(function() {
            toast('Request failed.', 'error');
        });
    });

    document.getElementById('metis-transaction-campaign-form')?.addEventListener('submit', function(event) {
        event.preventDefault();
        var form = event.currentTarget;
        var campaignCode = String(form.campaign_code.value || '').trim();
        if (!campaignCode) {
            toast('Select a campaign before saving.', 'warning');
            return;
        }

        post('metis_update_transaction_campaign', {
            tid: form.tid.value,
            campaign_code: campaignCode
        }).then(function(result) {
            if (!result || !result.success) {
                toast((result && result.data && result.data.message) || 'Failed to update campaign.', 'error');
                return;
            }
            var data = result.data || {};
            var label = document.getElementById('metis-transaction-campaign-label');
            if (label) {
                label.textContent = String(data.campaign_name || data.campaign_code || campaignCode);
            }
            toast('Campaign updated.', 'success');
        }).catch(function() {
            toast('Request failed.', 'error');
        });
    });
})();
</script>
